package com.hms.controller;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import com.hms.model.PathologicalTest;
import com.hms.model.RadiologicalTest;

/**
 *
 * @author ASUS
 */
public class PathologicalTestController {
    


}


