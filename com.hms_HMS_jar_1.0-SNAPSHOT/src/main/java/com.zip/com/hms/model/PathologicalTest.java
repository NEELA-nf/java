/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hms.model;

/**
 *
 * @author ASUS
 */
public class PathologicalTest {
    
    
    private String testTitle;
    private double cost;
    private boolean isAvailable;
    private String testType;
    private String reaagent;
  //  public PathologicalTest() {
        
   // }
   public PathologicalTest(String testTitle, 
            double cost, boolean isAvailable, String reagent){
        this.testTitle= testTitle;
        this.cost = cost;
        this.isAvailable = isAvailable;
        this.testType = testType;
        
    }
   
    public String show() {
        return String.format("Test Title: %s\nCost: %.2f\nAvailable: %s\nTest Type: %s",
                testTitle, cost, isAvailable ? "Yes" : "No", testType);
    }
  public String returnLabTestInfo(){
       String output = this.testTitle + this.cost +
               "This name: "+"\n<br>"             
               + "cost: "+"\n<br>"
               +"Availability: "+this.isIsAvailable();
      return output;
   }
  
 
           
   

   

    /**
     * @return the title
     */
    public String getTitle() {
        return testTitle;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.testTitle = title;
    }

    /**
     * @return the cost
     */
    public double getCost() {
        return cost;
    }

    /**
     * @param cost the cost to set
     */
    public void setCost(double cost) {
        this.cost = cost;
    }

    /**
     * @return the isAvailable
     */
    public boolean isIsAvailable() {
        return isAvailable;
    }

    /**
     * @param isAvailable the isAvailable to set
     */
    public void setIsAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }
    
}
