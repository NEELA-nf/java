/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hms.model;

/**
 *
 * @author ASUS
 */
public class RadiologicalTest extends LabTest{
     
  private  String plateDimention;

  public RadiologicalTest(String testTitle, 
            double cost, 
            boolean isAvailable,
            String plateDimention) {
        this.testTitle= testTitle;
        this.cost = cost;
        this.isAvailable = isAvailable;
        this.plateDimention = plateDimention;
        
        
    }
   public String returnLabTestInfo(){
       String output = this.testTitle + this.cost +
               "This name: "+"\n<br>"             
               + "cost: "+"\n<br>"
               +"Availability: "+this.isAvailable ;
      return output;
   }
}